// Queueing system for customer service (Queue-based)

let queue = ['Elaine', 'Althea', 'Angelo', 'Lito', 'Engelbert'];

function addCustomerToQueue() {
  let customerName = prompt("Enter your name:");
  queue.push(customerName);
  alert(`${customerName} has been added to the queue.`);
}

function serviceCustomer() {
  let customerNumber = parseInt(prompt("Enter the customer number to be serviced (1-5):"));
  
  if (customerNumber >= 1 && customerNumber <= queue.length) {
    let servicedCustomer = queue[customerNumber - 1];
    queue.splice(customerNumber - 1, 1); // Remove serviced customer
    alert(`${servicedCustomer} has been serviced.`);
    console.log("Updated Queue: " + queue.join(", "));
  } else {
    alert("Invalid customer number. Please enter a number between 1 and 5.");
  }
}

console.log("Initial Queue: " + queue.join(", "));
