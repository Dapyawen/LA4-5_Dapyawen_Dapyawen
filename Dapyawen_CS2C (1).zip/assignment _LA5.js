// Queueing system with hash function

let hashTable = {};

function hashFunction(name) {
  return name.length % 5; // Simple hash function based on name length
}

function addCustomerToHashTable() {
  let customerName = prompt("Enter your name:");
  let hashIndex = hashFunction(customerName);
  hashTable[hashIndex] = customerName;
  alert(`${customerName} has been added to the hash table at index ${hashIndex}.`);
}

function serviceCustomer() {
  let customerNumber = parseInt(prompt("Enter the customer number to be serviced (1-5):"));

  let foundCustomer = null;
  for (let key in hashTable) {
    if (hashTable[key] && customerNumber === parseInt(key) + 1) {
      foundCustomer = hashTable[key];
      delete hashTable[key];
      break;
    }
  }

  if (foundCustomer) {
    alert(`${foundCustomer} has been serviced.`);
    console.log("Updated Hash Table: ", hashTable);
  } else {
    alert("Invalid customer number.");
  }
}

console.log("Initial Hash Table: ", hashTable);
